/**
* 文件说明: 表单验证js库
* 文件名称: vform.js
* 最后更新: 2007-12-7
* @version	vForm ver 1.3 build 20071207
* @author	maker	<m4ker@163.com|http://www.m4ker.net>
*/

/**
* 验证规则
*/
var r={
	'require'   : /.+/,
	'email'     : /^(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)?$/,
	'percent'   : /^([-\+]?\d+(\.\d+)?%+)?$/,
	'number'    : /^\d*$/,
	'URL'       : /^([\w]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*)?$/,
	'httpURL'   : /^(http:\/\/[\w]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*)?$/,
	'integer'   : /^([-\+]?\d+)?$/,
	'float'     : /^([-\+]?\d+(\.\d+)?)?$/,
	'english'   : /^[A-Za-z]*$/,
	'phone'     : /^[\d-]*$/,
	'postcode'  : /^[1-9]?\d{0,5}$/,
	'chinese'   : /^[\u0391-\uFFE5]*$/,
	'nochinese' : /^[^\u0391-\uFFE5]*$/
};

/**
* 验证值是否符合指定规则
*/
function v(id,datatype,msg)
{
	ele = document.getElementById(id);
	if(new RegExp(r[datatype]).test(ele.value) == false)
	{
		alert(msg);
		ele.style.color = "red";
		ele.focus();
		return false;
	}else
		return true;
}

/**
* 限制表单项长度
*/
function len(id,_long,msg,_short,msg2)
{
	ele = document.getElementById(id);
	if(ele.value.length == 0)
	{
		return true;
	}else if(ele.value.length>_long)
	{
		alert(msg);
		ele.style.color = "red";
		ele.focus();
		return false;
	}else if(ele.value.length<_short)
	{
		alert(msg2);
		ele.style.color = "red";
		ele.focus();
		return false;
	}else
		return true;
}

/**
* 比较两个表单项值
*/
function s(id,id2,msg)
{
	ele_1 = document.getElementById(id);
	ele_2 = document.getElementById(id2);
	if(ele_1.value == ele_2.value)
	{
		return true;
	}else{
		alert(msg);
		ele_1.focus();
		return false;
	}
}
