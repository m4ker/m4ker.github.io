<?
/**
* 文件说明: 表单验证php类
* 文件名称: vform.js
* 最后更新: 2007-12-7
* @version	vForm ver 1.3 build 20071207
* @author	maker	<m4ker@163.com|http://www.m4ker.net>
*/
class vform
{
	/**
	* 验证设置
	*
	* array(array('函数名','参数1','参数2','参数3'...),array('函数名2','参数1','参数2','参数3'...)...)
	*/
	var $config = array();

	/**
	* js文件位置,在构造函数中初始化.
	*/
	var $source = '';

	/**
	* 验证表单id
	*/
	var $formid = '';

	/**
	* 绑定时间,默认为submit
	*/
	var $event = '';

    /**
    * 构造函数
    *
    * @param	array	$c	验证规则数组
	* @param	string	$f	表单id
	* @param	string	$s	js文件路径,不填写默认为vform.js
    */
	function vform($c,$f = '',$e = '',$s = '')
	{
		if($c){
			/**
			* 对象初始化
			*/
			$this->config   = $c;
			/**
			* 属性默认值
			*/
			$this->source = $s ? $s : 'vform.js' ;
			$this->formid = $f ? $f : 'form' ;
			$this->event  = $e ? $e : 'submit' ;
			return true;
		}else
			return false;
	}

	/**
	* 返回前端js调用代码
	*/
	function source()
	{
		return "<script language=\"JavaScript\" src=\"{$this->source}\" type=\"text/javascript\"></script>\n";
	}

	/**
	* 输出前端全部代码
	*
	* @param	boolean	$multi	定义是否输出js调用语句
	* @param	string	$f		表单id
	*/
	function p($multi = false, $f = '')//print
	{
		$formid = $f ? $f : $this->formid;
		if(!$multi)
			print($this->source());
		print($this->script($this->mkfunc($formid)));
	}

	/**
	* 将代码放入<script ...></script>中
	*
	* @param	string	$script	将要放入<script ...></script>中的代码
	*/
	function script($script)
	{
		return "<script language=\"JavaScript\" type=\"text/javascript\">\n<!--\n{$script}\n-->\n</script>\n";
	}

	function mkfunc($f = '')
	{
		$formid = $f ? $f : $this->formid;
		$str = '';
		$str.= "setTimeout(\"document.getElementById('$formid').on".$this->event." = function (){";
		$str.= "return ".$this->mkcond($this->config);
		$str.= ";}\",10);";
		return $str;
	}

	function mkcodes($config)
	{
		if($config)
		{
			$str = '';
			foreach($config as $c)
			{
				$c[0] = !$c[0] ? 'v' : $c[0];
				$str .= 'if('.$c[0].'(';
				for($j = 1; $j < count($c); $j++)
				{
					$str .= ($j != 1 ? ',' : '') . "'" . $c[$j] . "'";
				}
				$str .= '))return false;';
			}
			return $str;
		}else
			return false;
	}

	/**
	* 生成js函数中的if条件
	*/
	function mkcond($config)
	{
		if($config)
		{
			$str = '';
			$i = 0;
			foreach($config as $c)
			{
				$c[0] = !$c[0] ? 'v' : $c[0];
				$str .= ($i ? ' && ' : '').$c[0]."(";
				for($j = 1; $j < count($c); $j++)
				{
					$str .= ($j != 1 ? ',' : '') . "'" . $c[$j] . "'";
				}
				$str .=")";
				$i++;
			}
			return $str;
		}else
			return false;
	}

}